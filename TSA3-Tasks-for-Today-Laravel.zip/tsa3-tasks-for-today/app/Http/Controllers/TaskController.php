<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\View\View;

class TaskController extends Controller
{
    public function welcome(): View
    {
        $today = today(config('app.timezone'));
        $tasks = Task::query()->forToday()->orderBy('id')->get();
        $completed = $tasks->where('status', 'completed')->count();

        return view('tasks.today', compact('tasks', 'today', 'completed'));
    }

    public function index(): View
    {
        $tasks = Task::query()->orderBy('task_date')->orderBy('id')->get();
        $groupedTasks = $tasks->groupBy(fn (Task $task) => $task->task_date->format('Y-m-d'));

        return view('tasks.index', compact('tasks', 'groupedTasks'));
    }
}
