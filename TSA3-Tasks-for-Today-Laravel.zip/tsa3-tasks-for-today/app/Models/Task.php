<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    public const STATUSES = ['pending' => 'Pending', 'in_progress' => 'In progress', 'completed' => 'Completed'];

    protected $fillable = ['title', 'status', 'task_date'];

    protected function casts(): array
    {
        return ['task_date' => 'immutable_date'];
    }

    public function scopeForToday(Builder $query): Builder
    {
        return $query->whereDate('task_date', today(config('app.timezone'))->toDateString());
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status] ?? ucfirst(str_replace('_', ' ', $this->status));
    }
}
