<?php

namespace Tests\Feature;

use App\Models\Task;
use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonImmutable;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TaskManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        config(['app.timezone' => 'Asia/Manila']);
        $instant = CarbonImmutable::parse('2026-11-09 00:30:00', 'Asia/Manila');
        Carbon::setTestNow($instant);
        CarbonImmutable::setTestNow($instant);
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        CarbonImmutable::setTestNow();

        parent::tearDown();
    }

    public function test_seed_data_has_eight_tasks_across_three_dates_and_exactly_one_user(): void
    {
        $this->seed();
        $this->assertDatabaseCount('tasks', 8);
        $this->assertDatabaseCount('users', 1);
        $this->assertCount(3, Task::query()->get()->pluck('task_date')->map->toDateString()->unique());
        $this->assertSame(4, Task::query()->forToday()->count());
    }

    public function test_reseeding_updates_samples_without_duplicate_tasks_or_users(): void
    {
        $this->seed();
        config(['developer.username' => 'changed.username', 'developer.full_name' => 'Updated Developer']);
        $this->seed();

        $this->assertDatabaseCount('tasks', 8);
        $this->assertDatabaseCount('users', 1);
        $this->assertDatabaseHas('users', ['username' => 'changed.username', 'full_name' => 'Updated Developer']);
    }

    public function test_today_page_filters_using_the_manila_date_even_when_utc_is_yesterday(): void
    {
        $this->assertSame('2026-11-08', CarbonImmutable::now('UTC')->toDateString());
        Task::create(['title' => 'Yesterday record', 'task_date' => '2026-11-08']);
        Task::create(['title' => 'Current day record', 'task_date' => '2026-11-09']);
        Task::create(['title' => 'Tomorrow record', 'task_date' => '2026-11-10']);

        $this->get('/')->assertOk()->assertViewIs('tasks.today')
            ->assertSee('Current day record')->assertDontSee('Yesterday record')->assertDontSee('Tomorrow record');
    }

    public function test_all_tasks_page_shows_every_task_in_date_order(): void
    {
        Task::create(['title' => 'Latest scheduled record', 'task_date' => '2026-11-10']);
        Task::create(['title' => 'Earliest scheduled record', 'task_date' => '2026-11-08']);
        Task::create(['title' => 'Middle scheduled record', 'task_date' => '2026-11-09']);

        $this->get('/tasks')->assertOk()->assertViewIs('tasks.index')
            ->assertSeeInOrder(['Earliest scheduled record', 'Middle scheduled record', 'Latest scheduled record']);
    }

    public function test_profile_page_displays_the_stored_user(): void
    {
        User::create(['username' => 'profile.test', 'full_name' => 'Profile Test Person', 'email' => 'profile@example.com']);

        $this->get('/profile')->assertOk()->assertViewIs('profile')
            ->assertSee('Profile Test Person')->assertSee('profile.test')->assertSee('profile@example.com');
    }

    public function test_static_about_page_identifies_the_configured_developer(): void
    {
        config(['developer.full_name' => 'Configured Developer']);

        $this->get('/about')->assertOk()->assertViewIs('about')->assertSee('Configured Developer');
    }

    public function test_empty_pages_display_helpful_messages(): void
    {
        $this->get('/')->assertOk()->assertSee('No tasks are scheduled for today.');
        $this->get('/tasks')->assertOk()->assertSee('No tasks have been added yet.');
        $this->get('/profile')->assertOk()->assertSee('No profile available.');
    }

    public function test_task_status_defaults_to_pending_and_dates_are_cast(): void
    {
        $task = Task::create(['title' => 'Default status record', 'task_date' => '2026-11-09'])->fresh();

        $this->assertSame('pending', $task->status);
        $this->assertSame('2026-11-09', $task->task_date->toDateString());
        $this->assertSame('Pending', $task->statusLabel());
    }

    public function test_database_enforces_unique_usernames(): void
    {
        User::create(['username' => 'same.username', 'full_name' => 'First Person', 'email' => 'first@example.com']);
        $this->expectException(QueryException::class);

        User::create(['username' => 'same.username', 'full_name' => 'Second Person', 'email' => 'second@example.com']);
    }

    public function test_blade_escapes_stored_task_titles(): void
    {
        Task::create(['title' => '<script>alert(1)</script>', 'task_date' => '2026-11-09']);

        foreach (['/', '/tasks'] as $page) {
            $this->get($page)->assertOk()->assertSee('&lt;script&gt;alert(1)&lt;/script&gt;', false)
                ->assertDontSee('<script>alert(1)</script>', false);
        }
    }

    public function test_today_page_changes_when_the_clock_moves_to_the_next_day(): void
    {
        Task::create(['title' => 'Previous day task', 'task_date' => '2026-11-09']);
        Task::create(['title' => 'New day task', 'task_date' => '2026-11-10']);
        $nextDay = CarbonImmutable::parse('2026-11-10 00:01:00', 'Asia/Manila');
        Carbon::setTestNow($nextDay);
        CarbonImmutable::setTestNow($nextDay);

        $this->get('/')->assertOk()->assertSee('New day task')->assertDontSee('Previous day task');
    }
}
