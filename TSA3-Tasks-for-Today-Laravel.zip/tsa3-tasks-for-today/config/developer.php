<?php

return [
    'full_name' => env('DEVELOPER_NAME', 'Johfreeh P. Fajardo'),
    'username' => env('DEVELOPER_USERNAME', 'Yofuri'),
    'email' => env('DEVELOPER_EMAIL', 'johfpinedafajardo@gmail.com'),
    'description' => 'A web development student learning to build practical applications with Laravel. I created Tasks for Today to organize daily priorities and practice working with database-backed applications.',
    'section' => env('DEVELOPER_SECTION', ''),
    'professor' => env('DEVELOPER_PROFESSOR', ''),
];
