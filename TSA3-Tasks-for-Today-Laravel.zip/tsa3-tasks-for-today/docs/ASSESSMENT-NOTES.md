# TSA3 assessment notes

## Requirement mapping

| Requirement | Implementation |
| --- | --- |
| Tasks migration | Title, pending default status, indexed task date, ID, and timestamps |
| Users migration | Unique username, full name, email, ID, and timestamps |
| Eight tasks across at least three dates | Eight tasks spanning yesterday, today, and tomorrow |
| Exactly one user | Single Johfreeh P. Fajardo profile; repeat seeding updates it |
| Task and User models | Eloquent models in `app/Models` |
| Today's tasks only | `Task::forToday()` scope used by the Welcome action |
| Every task ordered by date | Date and ID ordering in the task list action |
| Profile | Database-backed record displayed by `ProfileController` |
| Static About | Blade view identifying Johfreeh P. Fajardo as the developer |
| Documentation | README with setup, schema, sample data, testing, and submission instructions |

## Date handling

The application uses Asia/Manila as its default timezone. The task seeder and Welcome page calculate today from that same setting. Dates are not hardcoded in the application, so reseeding creates examples around the date on which the project is run.

Tests freeze the clock shortly after midnight in Manila, while the UTC date is still the previous day. They confirm that the Welcome page uses Manila's date. A separate test advances the clock to the next day and verifies that the displayed task changes.

## Developer description

A web development student learning to build practical applications with Laravel. I created Tasks for Today to organize daily priorities and practice working with database-backed applications.

## Verification completed

- Eleven feature tests passed with 43 assertions.
- All four required routes returned HTTP 200 in browser checks.
- The Welcome page displayed four seeded tasks for today.
- The Task List displayed all eight seeded tasks.
- Navigation between all pages worked.
- Developer identity was confirmed on Profile and About.
- Desktop and mobile page screenshots were captured and inspected.
- Blade templates compiled successfully.

The previous TSA1 data and source were not provided, so the sample titles and presentation are new. The profile uses the developer's supplied name, username, and email address. GitHub publication and hosting remain submission steps; the local preview is not a public hosted link.
