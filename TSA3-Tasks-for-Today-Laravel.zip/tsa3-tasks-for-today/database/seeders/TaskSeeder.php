<?php

namespace Database\Seeders;

use App\Models\Task;
use Carbon\CarbonImmutable;
use Illuminate\Database\Seeder;

class TaskSeeder extends Seeder
{
    public function run(): void
    {
        $today = CarbonImmutable::today(config('app.timezone'));
        $samples = [
            ['title' => 'Review last week\'s lecture notes', 'status' => 'completed', 'offset' => -1],
            ['title' => 'Organize project references', 'status' => 'completed', 'offset' => -1],
            ['title' => 'Review Laravel migration fields', 'status' => 'completed', 'offset' => 0],
            ['title' => 'Finish the task list layout', 'status' => 'in_progress', 'offset' => 0],
            ['title' => 'Test the date filter', 'status' => 'pending', 'offset' => 0],
            ['title' => 'Update the project README', 'status' => 'pending', 'offset' => 0],
            ['title' => 'Prepare the assessment screenshots', 'status' => 'pending', 'offset' => 1],
            ['title' => 'Review the deployment checklist', 'status' => 'pending', 'offset' => 1],
        ];

        foreach ($samples as $sample) {
            Task::updateOrCreate(['title' => $sample['title']], [
                'status' => $sample['status'],
                'task_date' => $today->addDays($sample['offset'])->toDateString(),
            ]);
        }
    }
}
