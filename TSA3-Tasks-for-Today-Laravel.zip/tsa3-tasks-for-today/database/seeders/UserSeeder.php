<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use RuntimeException;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        if (User::query()->count() > 1) {
            throw new RuntimeException('This assessment requires exactly one user. Review the existing user records before seeding.');
        }

        $user = User::query()->first() ?? new User;
        $user->fill([
            'username' => config('developer.username'),
            'full_name' => config('developer.full_name'),
            'email' => config('developer.email'),
        ])->save();
    }
}
