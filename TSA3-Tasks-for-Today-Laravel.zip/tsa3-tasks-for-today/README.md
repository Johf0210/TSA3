# IT0049 TSA3 Tasks for Today Management System

A Laravel 13 application by Johfreeh P. Fajardo, username **Yofuri**. It provides a Welcome page showing only today's tasks, a full task list ordered by date, a single-user profile, and a static About page.

This is a standalone implementation of the supplied TSA3 requirements. The previous TSA1 source and data were not supplied, so the project uses new sample task titles rather than claiming to reproduce the earlier dataset exactly.

## Requirements

- PHP 8.5, the verified runtime for the included dependency lock file.
- Composer 2.
- PHP extensions including PDO SQLite, mbstring, DOM, XML, fileinfo, OpenSSL, and cURL.
- PDO MySQL if you select MySQL instead of SQLite.

No Node.js installation or frontend build is needed. The pages use a local stylesheet with no external font or image requests.

## Start on this computer

Open this project in VS Code and run:

```powershell
.\start-local.cmd
```

You can also double-click the launcher. It uses the previously installed PHP runtime from the neighboring `laravel-tools` folder if available, otherwise PHP on PATH. It installs missing dependencies, creates a local `.env` and SQLite database when missing, applies migrations, seeds sample data, and starts the server.

Open <http://127.0.0.1:8001>. Press Ctrl+C in the server window to stop.

The launcher reseeds the demonstration data each time it starts. This refreshes sample dates around today's date and resets sample task statuses. It is intended for this assessment, not for preserving edits to those sample tasks. To start without reseeding, use `php artisan serve --port=8001` instead.

## Install from the source ZIP or GitHub

Extract the archive and open the `tsa3-tasks-for-today` directory. Run:

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
php -r "file_exists('database/database.sqlite') || touch('database/database.sqlite');"
php artisan migrate --seed
php artisan serve --port=8001
```

Copy `.env.example` only for initial setup; do not overwrite an existing `.env`. The source archive intentionally excludes installed dependencies, private configuration, and the generated local database. Migrations and seeders recreate the database.

## Developer identity

The Profile and About pages are configured for **Johfreeh P. Fajardo**, username **Yofuri**. The short developer description is in `config/developer.php`.

The email address is configured as **johfpinedafajardo@gmail.com**, as supplied by the developer. You can change the identity settings in `.env`. Optional section and professor settings are also available:

```dotenv
DEVELOPER_NAME="Johfreeh P. Fajardo"
DEVELOPER_USERNAME=Yofuri
DEVELOPER_EMAIL=johfpinedafajardo@gmail.com
DEVELOPER_SECTION=
DEVELOPER_PROFESSOR=
```

After changing those settings, run:

```powershell
php artisan config:clear
php artisan db:seed --class=UserSeeder
```

This updates the existing single profile instead of adding another user. About is a static Blade page using configuration; Profile reads its user record through Eloquent.

## Required pages

| Route | Behavior | Source |
| --- | --- | --- |
| `/` | Only tasks whose `task_date` is today | `TaskController::welcome`, `tasks.today` |
| `/tasks` | Every task, ordered by date ascending and then ID | `TaskController::index`, `tasks.index` |
| `/profile` | The single stored user's username, full name, and email | `ProfileController::show`, `profile` |
| `/about` | Project purpose and developer identity | Static `about` Blade view |

The status marks are display indicators, not interactive checkboxes. The assessment specifies reading and displaying tasks; authentication, task editing, and task creation forms are outside this implementation.

## Database schema

| Table | Fields |
| --- | --- |
| `tasks` | `id`, `title` string(255), `status` string(30) default `pending`, `task_date` date indexed, `created_at`, `updated_at` |
| `users` | `id`, `username` string(50) unique, `full_name` string(150), `email` string(255), `created_at`, `updated_at` |

Required business fields are non-nullable. IDs use Laravel's standard auto-incrementing primary key. No password is required by this assessment; `User` extends Eloquent `Model` and represents a profile rather than a login account.

## Sample data and dates

The seeder inserts **eight tasks across three dates** and **exactly one user** in a fresh database.

| Relative date | Title | Status |
| --- | --- | --- |
| Yesterday | Review last week's lecture notes | completed |
| Yesterday | Organize project references | completed |
| Today | Review Laravel migration fields | completed |
| Today | Finish the task list layout | in_progress |
| Today | Test the date filter | pending |
| Today | Update the project README | pending |
| Tomorrow | Prepare the assessment screenshots | pending |
| Tomorrow | Review the deployment checklist | pending |

Dates are calculated when the seeder runs. `APP_TIMEZONE=Asia/Manila` controls both the seeder's date and the Welcome page's date filter. There is no hardcoded current date in application code. `Task::forToday()` applies `whereDate` to the Eloquent query, so filtering happens before records are retrieved.

Repeating the seeder updates its eight samples by title instead of duplicating them. It also updates the existing profile. If the database already contains more than one user, seeding stops and asks you to review the records rather than silently deleting them. The one-user rule is enforced by the seed workflow, not a database-wide row-count constraint.

## MySQL alternative

Create a MySQL database named `tsa3_tasks`, then set these values in `.env`, using your actual credentials:

```dotenv
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=tsa3_tasks
DB_USERNAME=root
DB_PASSWORD=
```

Run `php artisan config:clear` followed by `php artisan migrate --seed`. SQLite is the verified database for this project; the MySQL connection instructions have not been tested against a running server here.

## Project structure and data flow

- `database/migrations`: table structures and rollback definitions.
- `database/seeders`: sample tasks and the single developer profile.
- `app/Models/Task.php`: task fields, date casting, and the reusable today query scope.
- `app/Models/User.php`: profile model.
- `app/Http/Controllers/TaskController.php`: today and complete task queries.
- `app/Http/Controllers/ProfileController.php`: profile retrieval.
- `routes/web.php`: the four required routes.
- `resources/views/layouts/app.blade.php`: shared layout and navigation.
- `resources/views/partials/task-row.blade.php`: shared task presentation.
- `resources/views/tasks`: distinct Today and Task List pages.
- `resources/views/profile.blade.php` and `about.blade.php`: profile and developer pages.
- `public/css/app.css`: responsive local styling.

Controllers retrieve Eloquent model collections and pass them to Blade. Seed arrays populate the database only; they do not serve as the pages' data source. Blade's escaped `{{ }}` output prevents stored titles or profile values from being treated as HTML.

## Verification

```powershell
php artisan test
php artisan migrate:status
```

Tests use a separate in-memory SQLite database. They verify today's filter at Manila midnight when UTC is still the previous day, changing dates, full date ordering, required seed counts, repeat seeding, profile and About output, empty states, default pending status, unique usernames, and escaped task titles.

Browser screenshots are saved under `docs/`. The Today page, Task List, Profile, and About page are checked on desktop and mobile.

![Today page](docs/today-desktop.png)

![All tasks](docs/tasks-desktop.png)

![Profile](docs/profile-desktop.png)

![About the developer](docs/about-desktop.png)

## Submission

1. Review your developer details and description. Add section and professor details if required by your instructor.
2. Upload the raw source files to a GitHub repository, including `composer.json`, `composer.lock`, migrations, seeders, models, controllers, views, and this README.
3. Do not upload `.env`, `vendor`, generated SQLite files, or logs. Dependencies are restored with Composer.
4. Deploy to a PHP-capable host with its web root set to `public`. Set a private `APP_KEY`, the actual `APP_URL`, `APP_ENV=production`, and `APP_DEBUG=false`. Use persistent database storage.
5. Run migrations and seeders on the host, then verify all four pages.
6. Submit the GitHub repository URL and the public hosted application URL. A localhost address is only a local preview.

GitHub publication and hosting have not been performed as part of this standalone build.

## References

- [Laravel Eloquent and query scopes](https://laravel.com/docs/13.x/eloquent#query-scopes)
- [Laravel migrations](https://laravel.com/docs/13.x/migrations)
- [Laravel seeding](https://laravel.com/docs/13.x/seeding)
- [Laravel Blade](https://laravel.com/docs/13.x/blade)
