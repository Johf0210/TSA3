@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0..\laravel-tools\php\php.exe" set "PATH=%~dp0..\laravel-tools\php;%PATH%"
where php >nul 2>nul
if errorlevel 1 (
    echo PHP was not found. Install PHP 8.5 and Composer or use the configured VS Code terminal.
    pause
    exit /b 1
)
php -r "exit(version_compare(PHP_VERSION, '8.5.0', '>=') ? 0 : 1);"
if errorlevel 1 (
    echo This project was verified with PHP 8.5. Your terminal is using an older version.
    php -v
    pause
    exit /b 1
)
if not exist vendor\autoload.php (
    call composer install --no-interaction
    if errorlevel 1 goto :failed
)
if not exist .env (
    copy /y .env.example .env >nul
    php artisan key:generate
    if errorlevel 1 goto :failed
)
php -r "file_exists('database/database.sqlite') || touch('database/database.sqlite');"
if errorlevel 1 goto :failed
php artisan migrate --seed --no-interaction
if errorlevel 1 goto :failed
echo.
echo Open http://127.0.0.1:8001 in your browser. Press Ctrl+C to stop.
php artisan serve --host=127.0.0.1 --port=8001
exit /b %errorlevel%
:failed
echo Setup failed. Review the error above before trying again.
pause
exit /b 1
