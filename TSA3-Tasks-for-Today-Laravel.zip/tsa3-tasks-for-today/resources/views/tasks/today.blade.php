@extends('layouts.app')
@section('title', 'Today')

@section('content')
<div class="page-heading"><div><p class="eyebrow">A FRESH START</p><h1>Focus on today.</h1><p class="subtitle">A clear view of what needs your attention.</p></div><span class="day-stamp"><strong>{{ $today->format('d') }}</strong><span>{{ strtoupper($today->format('M')) }}</span></span></div>
<div class="summary-grid">
    <section class="summary"><span class="summary-label">Scheduled today</span><strong>{{ $tasks->count() }}</strong><span class="summary-detail">Tasks on your list</span></section>
    <section class="summary"><span class="summary-label">Completed</span><strong>{{ $completed }}</strong><span class="summary-detail">A little progress counts</span></section>
    <section class="summary summary-accent"><span class="summary-label">Still to do</span><strong>{{ $tasks->count() - $completed }}</strong><span class="summary-detail">Take the next small step</span></section>
</div>
<section class="task-panel" aria-labelledby="today-heading">
    <div class="panel-heading"><div><p class="eyebrow">{{ strtoupper($today->format('l, F j')) }}</p><h2 id="today-heading">Today's tasks <span class="count">{{ $tasks->count() }}</span></h2></div><a class="text-link" href="{{ route('tasks.index') }}">View all tasks <span aria-hidden="true">↗</span></a></div>
    <ul class="task-list">
        @forelse ($tasks as $task)
            @include('partials.task-row', ['task' => $task])
        @empty
            <li class="empty-state"><strong>A little breathing room.</strong><span>No tasks are scheduled for today.</span><a href="{{ route('tasks.index') }}">Browse all tasks</a></li>
        @endforelse
    </ul>
</section>
<p class="page-note">Only tasks scheduled for today are shown here.</p>
@endsection
