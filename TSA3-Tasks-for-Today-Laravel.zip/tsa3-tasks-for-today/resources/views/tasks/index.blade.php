@extends('layouts.app')
@section('title', 'Task list')

@section('content')
<div class="page-heading"><div><p class="eyebrow">THE BIGGER PICTURE</p><h1>Your task list.</h1><p class="subtitle">Everything on your schedule, from the earliest date to the latest.</p></div><span class="total-label">{{ $tasks->count() }} tasks</span></div>
@forelse ($groupedTasks as $date => $dateTasks)
    <section class="task-panel dated-panel" aria-labelledby="date-{{ $loop->index }}">
        <div class="panel-heading"><div><p class="eyebrow">{{ $dateTasks->first()->task_date->format('F j, Y') }}</p><h2 id="date-{{ $loop->index }}">{{ $dateTasks->first()->task_date->format('l') }} @if($date === today(config('app.timezone'))->toDateString())<span class="today-chip">Today</span>@endif</h2></div><span class="muted">{{ $dateTasks->count() }} tasks</span></div>
        <ul class="task-list">@foreach ($dateTasks as $task) @include('partials.task-row', ['task' => $task]) @endforeach</ul>
    </section>
@empty
    <section class="task-panel empty-state"><strong>Your list is clear.</strong><span>No tasks have been added yet.</span></section>
@endforelse
@endsection
