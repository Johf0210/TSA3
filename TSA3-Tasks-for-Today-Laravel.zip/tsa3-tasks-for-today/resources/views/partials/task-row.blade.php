<li class="task-row">
    <span @class(['task-mark', 'done' => $task->status === 'completed', 'working' => $task->status === 'in_progress']) aria-hidden="true">{{ $task->status === 'completed' ? '✓' : ($task->status === 'in_progress' ? '•' : '') }}</span>
    <div class="task-copy"><span @class(['task-title', 'finished' => $task->status === 'completed'])>{{ $task->title }}</span><span class="task-date">{{ $task->task_date->format('l, F j') }}</span></div>
    <span class="status status-{{ $task->status }}">{{ $task->statusLabel() }}</span>
</li>
