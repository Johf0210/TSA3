<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') | Tasks for Today</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to content</a>
    <aside class="sidebar">
        <a class="brand" href="{{ route('welcome') }}"><span class="brand-mark" aria-hidden="true">t.</span><span>tasks<span class="brand-second">for today</span></span></a>
        <span class="nav-label">YOUR WORKSPACE</span>
        <nav aria-label="Main navigation">
            @foreach ([['welcome', '01', 'Today'], ['tasks.index', '02', 'Task list'], ['profile', '03', 'Profile'], ['about', '04', 'About']] as [$route, $number, $label])
                <a href="{{ route($route) }}" @class(['nav-link', 'active' => request()->routeIs($route)]) @if(request()->routeIs($route)) aria-current="page" @endif><span class="nav-number">{{ $number }}</span>{{ $label }}</a>
            @endforeach
        </nav>
        <div class="sidebar-note"><span class="note-label">A LITTLE EVERY DAY</span><p>Make room for what<br>matters today.</p></div>
        <div class="sidebar-footer">IT0049 <span aria-hidden="true">/</span> TSA3</div>
    </aside>
    <div class="workspace">
        <header class="topbar"><span>Tasks for Today Management System</span><time datetime="{{ today(config('app.timezone'))->toDateString() }}">{{ today(config('app.timezone'))->format('M j, Y') }}</time></header>
        <main id="main-content" class="main">
            @yield('content')
            <footer class="footer"><span>One task at a time.</span><span>Tasks for Today</span></footer>
        </main>
    </div>
</body>
</html>
