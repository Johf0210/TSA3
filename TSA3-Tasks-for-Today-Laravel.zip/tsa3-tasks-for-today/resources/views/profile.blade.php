@extends('layouts.app')
@section('title', 'Profile')

@section('content')
<div class="page-heading"><div><p class="eyebrow">A SPACE FOR YOU</p><h1>My profile.</h1><p class="subtitle">The person behind the daily plan.</p></div></div>
@if ($user)
<section class="profile-card" aria-labelledby="profile-name">
    <div class="profile-intro"><span class="avatar" aria-hidden="true">{{ mb_strtoupper(mb_substr($user->full_name, 0, 1)) }}</span><div><span class="eyebrow">WORKSPACE OWNER</span><h2 id="profile-name">{{ $user->full_name }}</h2><p>{{ '@'.$user->username }}</p></div></div>
    <dl class="profile-fields">
        <div><dt>Full name</dt><dd>{{ $user->full_name }}</dd></div>
        <div><dt>Username</dt><dd>{{ $user->username }}</dd></div>
        <div><dt>{{ str_ends_with($user->email, '@example.com') ? 'Email address (sample)' : 'Email address' }}</dt><dd>{{ $user->email }}</dd></div>
    </dl>
</section>
@else
<section class="task-panel empty-state"><strong>No profile available.</strong><span>The workspace profile has not been set up yet.</span></section>
@endif
@endsection
