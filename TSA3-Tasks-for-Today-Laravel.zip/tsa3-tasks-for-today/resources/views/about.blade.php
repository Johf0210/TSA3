@extends('layouts.app')
@section('title', 'About')

@section('content')
<div class="page-heading"><div><p class="eyebrow">BEHIND THE PROJECT</p><h1>A simpler daily view.</h1><p class="subtitle">A small workspace for keeping track of the things that matter.</p></div></div>
<section class="about-card"><span class="about-icon" aria-hidden="true">t.</span><h2>Tasks for Today</h2><p>This task management system brings today's priorities, the complete task list, and a personal profile into one place. It is a Laravel application created for IT0049 Technical Summative Assessment 3.</p><p>The Welcome page focuses on the current day, while the Task List page keeps the full schedule available in date order.</p><div class="developer"><span class="eyebrow">DEVELOPED BY</span><h3>{{ config('developer.full_name') }}</h3><p>{{ config('developer.email') }}@if(str_ends_with(config('developer.email'), '@example.com')) (sample email)@endif</p><p>{{ config('developer.description') }}</p>@if(config('developer.section'))<p>Section: {{ config('developer.section') }}</p>@endif @if(config('developer.professor'))<p>Professor: {{ config('developer.professor') }}</p>@endif</div></section>
@endsection
